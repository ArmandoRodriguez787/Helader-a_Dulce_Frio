package heladeria.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class LoginController {

    @FXML private TextField     txtUsuario;
    @FXML private PasswordField txtContrasena;
    @FXML private Label         lblError;

 
    private static final String USUARIO_ADMIN = "admin";
    private static final String PASS_ADMIN    = "1234";

    @FXML
    private void handleLogin(ActionEvent event) {
        String usuario    = txtUsuario.getText().trim();
        String contrasena = txtContrasena.getText();
  if (usuario.isEmpty() || contrasena.isEmpty()) {
            mostrarError("Por favor completa todos los campos.");
            return;
        }

     
        if (usuario.equals(USUARIO_ADMIN) && contrasena.equals(PASS_ADMIN)) {
            
            ocultarError();
        } else {
            mostrarError("Usuario o contraseña incorrectos.");
        }
    }
     private void mostrarError(String mensaje) {
        lblError.setText(mensaje);
        lblError.setVisible(true);
        lblError.setManaged(true);
    }

    private void ocultarError() {
        lblError.setVisible(false);
        lblError.setManaged(false);
    }
   
}
