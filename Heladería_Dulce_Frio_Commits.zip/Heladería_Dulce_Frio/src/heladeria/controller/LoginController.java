package heladeria.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class LoginController {

    @FXML private TextField     txtUsuario;
    @FXML private PasswordField txtContrasena;
    @FXML private Label         lblError;

 
    private static final String USUARIO_ADMIN = "admin";
    private static final String PASS_ADMIN    = "1234";

    @FXML
    private void handleLogin(ActionEvent event) {
        String usuario    = txtUsuario.getText().trim();
        String contrasena = txtContrasena.getText();

    }
   
}
