package heladeria.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class LoginController {

    @FXML private TextField     txtUsuario;
    @FXML private PasswordField txtContrasena;
    @FXML private Label         lblError;

    // Credenciales de prueba
    private static final String USUARIO_ADMIN = "admin";
    private static final String PASS_ADMIN    = "1234";

   
}
