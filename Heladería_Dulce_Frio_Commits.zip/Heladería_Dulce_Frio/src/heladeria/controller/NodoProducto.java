package heladeria.controller;

/**
 * Nodo de la lista doblemente enlazada.
 * Almacena un producto (nombre, precio, detalle).
 */
public class NodoProducto {

    public String nombre;
    public int    precio;
    public String detalle; // para el carrito: describe el item

    public NodoProducto anterior;
    public NodoProducto siguiente;

    public NodoProducto(String nombre, int precio, String detalle) {
        this.nombre   = nombre;
        this.precio   = precio;
        this.detalle  = detalle;
        this.anterior = null;
        this.siguiente = null;
    }
}
