package heladeria.controller;

/**
 * Lista doblemente enlazada genérica para productos del catálogo y carrito.
 */
public class ListaDobleProducto {

    private NodoProducto cabeza;
    private NodoProducto cola;
    private int          tamano;

    public ListaDobleProducto() {
        cabeza = null;
        cola   = null;
        tamano = 0;
    }

    public NodoProducto getCrearNodo(String nombre, int precio, String detalle) {
        return new NodoProducto(nombre, precio, detalle);
    }


    public void addInicio(String nombre, int precio, String detalle) {
        NodoProducto nuevo = getCrearNodo(nombre, precio, detalle);
        if (cabeza == null) {
            cabeza = nuevo;
            cola   = nuevo;
        } else {
            nuevo.siguiente  = cabeza;
            cabeza.anterior  = nuevo;
            cabeza           = nuevo;
        }
        tamano++;
    }
    
    public void addUltimo(String nombre, int precio, String detalle) {
        NodoProducto nuevo = getCrearNodo(nombre, precio, detalle);
        if (cola == null) {
            cabeza = nuevo;
            cola   = nuevo;
        } else {
            nuevo.anterior  = cola;
            cola.siguiente  = nuevo;
            cola            = nuevo;
        }
        tamano++;
    }

    public NodoProducto buscarNodo(String nombre) {
        NodoProducto actual = cabeza;
        while (actual != null) {
            if (actual.nombre.equalsIgnoreCase(nombre)) {
                return actual;
            }
            actual = actual.siguiente;
        }
        return null; // no encontrado
    }

   
    public boolean eliminar(String nombre) {
        NodoProducto nodo = buscarNodo(nombre);
        if (nodo == null) return false;

        if (nodo.anterior != null) {
            nodo.anterior.siguiente = nodo.siguiente;
        } else {
            cabeza = nodo.siguiente; // era la cabeza
        }

        if (nodo.siguiente != null) {
            nodo.siguiente.anterior = nodo.anterior;
        } else {
            cola = nodo.anterior; // era la cola
        }

        tamano--;
        return true;
    }


    public NodoProducto eliminarPrimero() {
        if (cabeza == null) return null;
        NodoProducto eliminado = cabeza;
        cabeza = cabeza.siguiente;
        if (cabeza != null) cabeza.anterior = null;
        else cola = null;
        tamano--;
        return eliminado;
    }
    public NodoProducto getCabeza()  { return cabeza; }
    public NodoProducto getCola()    { return cola;   }
    public int          getTamano()  { return tamano; }
    public boolean      estaVacia()  { return tamano == 0; }

    public void vaciar() {
        cabeza = null;
        cola   = null;
        tamano = 0;
    }

 
    public NodoProducto getNodo(int indice) {
        if (indice < 0 || indice >= tamano) return null;
        NodoProducto actual = cabeza;
        for (int i = 0; i < indice; i++) {
            actual = actual.siguiente;
        }
        return actual;
    }

 
    public int calcularTotal() {
        int total = 0;
        NodoProducto actual = cabeza;
        while (actual != null) {
            total += actual.precio;
            actual = actual.siguiente;
        }
        return total;
    }
}


    
