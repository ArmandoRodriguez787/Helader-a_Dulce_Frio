package heladeria.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class AdminController implements Initializable {

    @FXML private VBox   vbSabores;
    @FXML private VBox   vbAdiciones;
    @FXML private Label  lblGuardado;

 
    private static final String[][] SABORES = {
        {"Fresa",       "1000"},
        {"Frambuesa",   "1100"},
        {"Chocolate",   "1000"},
        {"Avellana",    "1500"},
        {"Mandarina",   "1500"},
        {"Pistacho",    "2000"},
        {"Vainilla",    "1000"},
        {"Brownie",     "1100"},
        {"Oreo",        "1500"},
        {"Tres Leches", "1500"},
        {"Macadamia",   "2000"},
        {"Mora",        "1000"}
    };


    private static final String[][] ADICIONES = {
        {"Chispitas de chocolate", "700"},
        {"M&Ms",                   "1000"},
        {"Mani",                   "700"},
        {"Cacao en polvo",         "700"},
        {"Milo en polvo",          "700"}
    };

    
    private int[] stockSabores   = {10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10};
    private int[] stockAdiciones = {20, 20, 20, 20, 20};

     @Override
    public void initialize(URL url, ResourceBundle rb) {
        lblGuardado.setVisible(false);
        construirFilasSabores();
        construirFilasAdiciones();
        
    }
    
     private void construirFilasSabores() {
        vbSabores.getChildren().clear();
        for (int i = 0; i < SABORES.length; i++) {
            final int idx = i;
            vbSabores.getChildren().add(
                crearFila(SABORES[i][0], SABORES[i][1], stockSabores[i], idx, true)
            );
        }
    }

    private void construirFilasAdiciones() {
        vbAdiciones.getChildren().clear();
        for (int i = 0; i < ADICIONES.length; i++) {
            final int idx = i;
            vbAdiciones.getChildren().add(
                crearFila(ADICIONES[i][0], ADICIONES[i][1], stockAdiciones[i], idx, false)
            );
        }
    }
 private HBox crearFila(String nombre, String precio, int stockActual,
                           int idx, boolean esSabor) {
        HBox fila = new HBox(14);
        fila.setAlignment(Pos.CENTER_LEFT);
        fila.setPadding(new Insets(12, 16, 12, 16));
        fila.setStyle(
            "-fx-background-color: white;" +
            "-fx-background-radius: 12;" +
            "-fx-border-color: #FFD6E8;" +
            "-fx-border-radius: 12;" +
            "-fx-border-width: 1;"
        );
          VBox info = new VBox(2);
        HBox.setHgrow(info, Priority.ALWAYS);
        Label lblNombre = new Label(nombre);
        lblNombre.setFont(Font.font("System", FontWeight.BOLD, 13));
        lblNombre.setTextFill(Color.web("#5C3317"));
        Label lblPrecio = new Label("$" + precio);
        lblPrecio.setFont(Font.font(11));
        lblPrecio.setTextFill(Color.web("#FF6B9D"));
        info.getChildren().addAll(lblNombre, lblPrecio);

      
        Label lblStock = new Label("Stock: " + stockActual);
        lblStock.setFont(Font.font(12));
        lblStock.setPrefWidth(100);

 
        Spinner<Integer> spinner = new Spinner<>(0, 999, stockActual);
        spinner.setEditable(true);
        spinner.setPrefWidth(90);

 
        Button btnGuardar = new Button("Guardar");
        btnGuardar.setStyle(
            "-fx-background-color: #4ECDC4;" +
            "-fx-text-fill: white;" +
            "-fx-font-weight: bold;" +
            "-fx-font-size: 12;" +
            "-fx-padding: 7 16;" +
            "-fx-background-radius: 8;" +
            "-fx-cursor: hand;"
        );

        fila.getChildren().addAll(info, lblStock, spinner, btnGuardar);
        return fila;
    }
 
    @FXML
    private void handleIrCatalogo(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/heladeria/controller/Catalogo.fxml")
            );
            Parent root = loader.load();
            Stage stage = (Stage) vbSabores.getScene().getWindow();
            stage.setScene(new Scene(root, 1000, 680));
            stage.setTitle("Heladeria Dulce Frio - Catalogo");
            stage.setResizable(true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleLogout(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/heladeria/controller/Login.fxml")
            );
            Parent root = loader.load();
            Stage stage = (Stage) vbSabores.getScene().getWindow();
            stage.setScene(new Scene(root, 420, 520));
            stage.setTitle("Heladeria Dulce Frio");
            stage.setResizable(false);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
