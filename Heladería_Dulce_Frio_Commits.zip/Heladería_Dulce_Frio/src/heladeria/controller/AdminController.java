package heladeria.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class AdminController implements Initializable {

    @FXML private VBox   vbSabores;
    @FXML private VBox   vbAdiciones;
    @FXML private Label  lblGuardado;

 
    private static final String[][] SABORES = {
        {"Fresa",       "1000"},
        {"Frambuesa",   "1100"},
        {"Chocolate",   "1000"},
        {"Avellana",    "1500"},
        {"Mandarina",   "1500"},
        {"Pistacho",    "2000"},
        {"Vainilla",    "1000"},
        {"Brownie",     "1100"},
        {"Oreo",        "1500"},
        {"Tres Leches", "1500"},
        {"Macadamia",   "2000"},
        {"Mora",        "1000"}
    };


    private static final String[][] ADICIONES = {
        {"Chispitas de chocolate", "700"},
        {"M&Ms",                   "1000"},
        {"Mani",                   "700"},
        {"Cacao en polvo",         "700"},
        {"Milo en polvo",          "700"}
    };

    
    private int[] stockSabores   = {10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10};
    private int[] stockAdiciones = {20, 20, 20, 20, 20};

     @Override
    public void initialize(URL url, ResourceBundle rb) {
        lblGuardado.setVisible(false);
        
    }
    @FXML
    private void handleIrCatalogo(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/heladeria/controller/Catalogo.fxml")
            );
            Parent root = loader.load();
            Stage stage = (Stage) vbSabores.getScene().getWindow();
            stage.setScene(new Scene(root, 1000, 680));
            stage.setTitle("Heladeria Dulce Frio - Catalogo");
            stage.setResizable(true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleLogout(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/heladeria/controller/Login.fxml")
            );
            Parent root = loader.load();
            Stage stage = (Stage) vbSabores.getScene().getWindow();
            stage.setScene(new Scene(root, 420, 520));
            stage.setTitle("Heladeria Dulce Frio");
            stage.setResizable(false);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
