package heladeria.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CatalogoController {

    @FXML private Label    lblUsuario;
    @FXML private Label    lblBadge;
    @FXML private Button   btnCarrito;
    @FXML private TabPane  tabPane;

    @FXML private FlowPane fpSaboresCono;
    @FXML private Label    lblSaborSelCono;
    @FXML private Label    lblTotalCono;
    @FXML private Button   btnAgregarCono;

    @FXML private FlowPane fpSaboresVaso;
    @FXML private VBox     vbAdiciones;
    @FXML private Label    lblSaborSelVaso;
    @FXML private Label    lblTotalVaso;
    @FXML private Button   btnAgregarVaso;

    @FXML private FlowPane            fpMeGusta;
    @FXML private ListView<String>    lvHistorial;

   
    private ListaDobleProducto listaSabores   = new ListaDobleProducto();
    private ListaDobleProducto listaAdiciones = new ListaDobleProducto();
    private ListaDobleProducto listaCarrito   = new ListaDobleProducto();
    private ListaDobleProducto listaMeGusta   = new ListaDobleProducto();

    private NodoProducto saborConoSelec  = null;
    private NodoProducto saborVasoSelec  = null;

    private List<String> adicionesSeleccionadas = new ArrayList<>();

    private List<ToggleButton> btnsCono = new ArrayList<>();
    private List<ToggleButton> btnsVaso = new ArrayList<>();


    @FXML
    public void initialize() {
        lblUsuario.setText("Usuario: admin");
        lblBadge.setVisible(false);
        cargarSabores();
        cargarAdiciones();
       
    }
    private void cargarSabores() {
        listaSabores.addUltimo("Fresa",       1000, "sabor");
        listaSabores.addUltimo("Frambuesa",   1100, "sabor");
        listaSabores.addUltimo("Chocolate",   1000, "sabor");
        listaSabores.addUltimo("Avellana",    1500, "sabor");
        listaSabores.addUltimo("Mandarina",   1500, "sabor");
        listaSabores.addUltimo("Pistacho",    2000, "sabor");
        listaSabores.addUltimo("Vainilla",    1000, "sabor");
        listaSabores.addUltimo("Brownie",     1100, "sabor");
        listaSabores.addUltimo("Oreo",        1500, "sabor");
        listaSabores.addUltimo("Tres Leches", 1500, "sabor");
        listaSabores.addUltimo("Macadamia",   2000, "sabor");
        listaSabores.addUltimo("Mora",        1000, "sabor");
    }

    private void cargarAdiciones() {
        listaAdiciones.addUltimo("Chispitas de chocolate", 700,  "adicion");
        listaAdiciones.addUltimo("M&Ms",                   1000, "adicion");
        listaAdiciones.addUltimo("Mani",                   700,  "adicion");
        listaAdiciones.addUltimo("Cacao en polvo",         700,  "adicion");
        listaAdiciones.addUltimo("Milo en polvo",          700,  "adicion");
    }


    
}
