package heladeria.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CatalogoController {

    @FXML private Label    lblUsuario;
    @FXML private Label    lblBadge;
    @FXML private Button   btnCarrito;
    @FXML private TabPane  tabPane;

    @FXML private FlowPane fpSaboresCono;
    @FXML private Label    lblSaborSelCono;
    @FXML private Label    lblTotalCono;
    @FXML private Button   btnAgregarCono;

    @FXML private FlowPane fpSaboresVaso;
    @FXML private VBox     vbAdiciones;
    @FXML private Label    lblSaborSelVaso;
    @FXML private Label    lblTotalVaso;
    @FXML private Button   btnAgregarVaso;

    @FXML private FlowPane            fpMeGusta;
    @FXML private ListView<String>    lvHistorial;

   
    private ListaDobleProducto listaSabores   = new ListaDobleProducto();
    private ListaDobleProducto listaAdiciones = new ListaDobleProducto();
    private ListaDobleProducto listaCarrito   = new ListaDobleProducto();
    private ListaDobleProducto listaMeGusta   = new ListaDobleProducto();

    private NodoProducto saborConoSelec  = null;
    private NodoProducto saborVasoSelec  = null;

    private List<String> adicionesSeleccionadas = new ArrayList<>();

    private List<ToggleButton> btnsCono = new ArrayList<>();
    private List<ToggleButton> btnsVaso = new ArrayList<>();


    @FXML
    public void initialize() {
        lblUsuario.setText("Usuario: admin");
        lblBadge.setVisible(false);
        cargarSabores();
        cargarAdiciones();
        construirTarjetasCono();
        construirTarjetasVaso();
        construirCheckboxAdiciones();
       
    }
    private void cargarSabores() {
    listaSabores.addUltimo("Fresa",       1000, "\uD83C\uDF53"); 
    listaSabores.addUltimo("Frambuesa",   1100, "\uD83E\uDEB1"); 
    listaSabores.addUltimo("Chocolate",   1000, "\uD83C\uDF6B"); 
    listaSabores.addUltimo("Avellana",    1500, "\uD83C\uDF30"); 
    listaSabores.addUltimo("Mandarina",   1500, "\uD83C\uDF4A"); 
    listaSabores.addUltimo("Pistacho",    2000, "\uD83C\uDF3F"); 
    listaSabores.addUltimo("Vainilla",    1000, "\uD83C\uDF66"); 
    listaSabores.addUltimo("Brownie",     1100, "\uD83D\uDFEB"); 
    listaSabores.addUltimo("Oreo",        1500, "\u26AB");       
    listaSabores.addUltimo("Tres Leches", 1500, "\uD83E\uDD5B"); 
    listaSabores.addUltimo("Macadamia",   2000, "\uD83E\uDD5C"); 
    listaSabores.addUltimo("Mora",        1000, "\uD83C\uDF47"); 
}

    private void cargarAdiciones() {
        listaAdiciones.addUltimo("Chispitas de chocolate", 700,  "adicion");
        listaAdiciones.addUltimo("M&Ms",                   1000, "adicion");
        listaAdiciones.addUltimo("Mani",                   700,  "adicion");
        listaAdiciones.addUltimo("Cacao en polvo",         700,  "adicion");
        listaAdiciones.addUltimo("Milo en polvo",          700,  "adicion");
    }
private void construirTarjetasCono() {
        fpSaboresCono.getChildren().clear();
        btnsCono.clear();
        NodoProducto actual = listaSabores.getCabeza();
        while (actual != null) {
            final NodoProducto nodo = actual;
            ToggleButton btn = crearTarjetaSabor(nodo.nombre, nodo.precio);
            btn.setOnAction(e -> seleccionarSaborCono(nodo, btn));
            btnsCono.add(btn);
            fpSaboresCono.getChildren().add(btn);
            actual = actual.siguiente;
        }
    }
 private void seleccionarSaborCono(NodoProducto nodo, ToggleButton btn) {
        NodoProducto encontrado = listaSabores.buscarNodo(nodo.nombre);
        if (encontrado == null) return;

        btnsCono.forEach(b -> estiloTarjeta(b, false));
        estiloTarjeta(btn, true);
        saborConoSelec = encontrado;

        int total = 1500 + encontrado.precio;
        lblSaborSelCono.setText(encontrado.nombre);
        lblTotalCono.setText("$" + String.format("%,d", total));
        btnAgregarCono.setDisable(false);
    }
 private void construirTarjetasVaso() {
        fpSaboresVaso.getChildren().clear();
        btnsVaso.clear();
        NodoProducto actual = listaSabores.getCabeza();
        while (actual != null) {
            final NodoProducto nodo = actual;
            ToggleButton btn = crearTarjetaSabor(nodo.nombre, nodo.precio);
            btn.setOnAction(e -> seleccionarSaborVaso(nodo, btn));
            btnsVaso.add(btn);
            fpSaboresVaso.getChildren().add(btn);
            actual = actual.siguiente;
        }
    }
   private void seleccionarSaborVaso(NodoProducto nodo, ToggleButton btn) {
        NodoProducto encontrado = listaSabores.buscarNodo(nodo.nombre);
        if (encontrado == null) return;

        btnsVaso.forEach(b -> estiloTarjeta(b, false));
        estiloTarjeta(btn, true);
        saborVasoSelec = encontrado;
        actualizarTotalVaso();
        btnAgregarVaso.setDisable(false);
    }
   private void construirCheckboxAdiciones() {
        vbAdiciones.getChildren().clear();
        NodoProducto actual = listaAdiciones.getCabeza();
        while (actual != null) {
            final NodoProducto nodo = actual;
            CheckBox cb = new CheckBox(
                nodo.nombre + "   +$" + String.format("%,d", nodo.precio)
            );
            cb.setFont(Font.font("System", 13));
            cb.setTextFill(Color.web("#5C3317"));
            cb.setPadding(new Insets(8, 12, 8, 12));
            cb.setMaxWidth(Double.MAX_VALUE);
            cb.setStyle("-fx-background-color: white; -fx-background-radius: 10;");
            cb.selectedProperty().addListener((obs, o, n) -> {
                // Buscar adicion en la lista para confirmar que existe
                NodoProducto adicion = listaAdiciones.buscarNodo(nodo.nombre);
                if (adicion == null) return;
                if (n) adicionesSeleccionadas.add(adicion.nombre);
                else   adicionesSeleccionadas.remove(adicion.nombre);
                cb.setStyle(n
                    ? "-fx-background-color: #E0FAF8; -fx-background-radius: 10;" +
                      "-fx-border-color: #4ECDC4; -fx-border-radius: 10;"
                    : "-fx-background-color: white; -fx-background-radius: 10;");
                actualizarTotalVaso();
            });
            vbAdiciones.getChildren().add(cb);
            actual = actual.siguiente;
        }
    }
    private void actualizarTotalVaso() {
        int sumAdic = 0;
        for (String nombreAdic : adicionesSeleccionadas) {
            NodoProducto nodo = listaAdiciones.buscarNodo(nombreAdic);
            if (nodo != null) sumAdic += nodo.precio;
        }
        int sabor = saborVasoSelec != null ? saborVasoSelec.precio : 0;
        int total = 2000 + sabor + sumAdic;
        lblSaborSelVaso.setText(
            saborVasoSelec != null ? saborVasoSelec.nombre : "Ninguno"
        );
        lblTotalVaso.setText("$" + String.format("%,d", total));
    }
     @FXML
    private void handleAgregarCono(ActionEvent e) {
        if (saborConoSelec == null) return;
        int total = 1500 + saborConoSelec.precio;
        String detalle = "Cono + " + saborConoSelec.nombre;
        listaCarrito.addUltimo("Cono de " + saborConoSelec.nombre, total, detalle);
        actualizarBadge();
        mostrarAlerta("Agregado",
            "Cono de " + saborConoSelec.nombre + " agregado al carrito.\nTotal: $"
            + String.format("%,d", total));
    }

    @FXML
    private void handleAgregarVaso(ActionEvent e) {
        if (saborVasoSelec == null) return;
        int sumAdic = 0;
        StringBuilder detalleAdic = new StringBuilder();
        for (String nombreAdic : adicionesSeleccionadas) {
            NodoProducto nodo = listaAdiciones.buscarNodo(nombreAdic);
            if (nodo != null) {
                sumAdic += nodo.precio;
                if (detalleAdic.length() > 0) detalleAdic.append(", ");
                detalleAdic.append(nodo.nombre);
            }
        }
        int total = 2000 + saborVasoSelec.precio + sumAdic;
        String detalle = detalleAdic.length() > 0
            ? detalleAdic.toString() : "Sin adiciones";
        listaCarrito.addUltimo("Vaso de " + saborVasoSelec.nombre, total, detalle);
        actualizarBadge();
        mostrarAlerta("Agregado",
            "Vaso de " + saborVasoSelec.nombre + " agregado al carrito.\nTotal: $"
            + String.format("%,d", total));
    }
      @FXML
    private void handleVerCarrito(ActionEvent e) {
        try {
            FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/heladeria/controller/Carrito.fxml")
            );
            Parent root = loader.load();
            CarritoController cc = loader.getController();
           
            Stage stage = new Stage();
            stage.setTitle("Mi Carrito");
            stage.setScene(new Scene(root, 520, 580));
            stage.setResizable(false);
            stage.show();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public void actualizarBadge() {
        int cant = listaCarrito.getTamano();
        lblBadge.setText(String.valueOf(cant));
        lblBadge.setVisible(cant > 0);
    }
     public ListaDobleProducto getListaCarrito() { return listaCarrito; }
     public void registrarCompra(int total) {
        String fecha = java.time.LocalDateTime.now()
            .format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
        lvHistorial.getItems().add(0,
            fecha + "   Total: $" + String.format("%,d", total));
    }
 @FXML
    private void handleLogout(ActionEvent e) {
        try {
            FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/heladeria/controller/Login.fxml")
            );
            Parent root = loader.load();
            Stage stage = (Stage) lblUsuario.getScene().getWindow();
            stage.setScene(new Scene(root, 420, 520));
            stage.setTitle("Heladeria Dulce Frio");
            stage.setResizable(false);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    private ToggleButton crearTarjetaSabor(String nombre, int precio) {
    ToggleButton btn = new ToggleButton();
    VBox content = new VBox(4);
    content.setAlignment(Pos.CENTER);

    // Emoji viene del campo detalle del nodo
    NodoProducto nodo = listaSabores.buscarNodo(nombre);
    Label lblEmoji = new Label(nodo != null ? nodo.detalle : "");
    lblEmoji.setFont(Font.font("Segoe UI Emoji", 24));

    Label lblNombre = new Label(nombre);
    lblNombre.setFont(Font.font("System", FontWeight.BOLD, 11));
    lblNombre.setTextFill(Color.web("#5C3317"));

    Label lblPrecio = new Label("$" + String.format("%,d", precio));
    lblPrecio.setFont(Font.font(10));
    lblPrecio.setTextFill(Color.web("#FF6B9D"));

    content.getChildren().addAll(lblEmoji, lblNombre, lblPrecio);
    btn.setGraphic(content);
    btn.setPrefSize(110, 90);
    estiloTarjeta(btn, false);
    return btn;
}

    private void estiloTarjeta(ToggleButton btn, boolean sel) {
        btn.setStyle(sel
            ? "-fx-background-color: #FFF0F6; -fx-background-radius: 12;" +
              "-fx-border-color: #FF6B9D; -fx-border-radius: 12; -fx-border-width: 2.5;"
            : "-fx-background-color: white; -fx-background-radius: 12;" +
              "-fx-border-color: #FFD6E8; -fx-border-radius: 12; -fx-border-width: 1.5;");
    }

    private void mostrarAlerta(String titulo, String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle(titulo);
        a.setHeaderText(null);
        a.setContentText(msg);
        a.showAndWait();
    }
}

    

