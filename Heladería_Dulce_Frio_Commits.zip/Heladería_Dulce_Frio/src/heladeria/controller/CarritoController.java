package heladeria.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class CarritoController {

    @FXML private VBox   vbItems;
    @FXML private Label  lblVacio;
    @FXML private Label  lblTotal;
    @FXML private Button btnConfirmar;

    private ListaDobleProducto   listaCarrito;
    private CatalogoController   catalogoController;

   

    @FXML
    private void handleConfirmar(ActionEvent e) {
        if (listaCarrito.estaVacia()) return;
        int total = listaCarrito.calcularTotal();
        // Vaciar la lista usando eliminarPrimero repetidamente
        while (!listaCarrito.estaVacia()) {
            listaCarrito.eliminarPrimero();
        }
        
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle("Pedido confirmado");
        a.setHeaderText(null);
        a.setContentText("Pedido registrado.\nTotal: $" + String.format("%,d", total));
        a.showAndWait();
        ((Stage) btnConfirmar.getScene().getWindow()).close();
    }

    @FXML
    private void handleCerrar(ActionEvent e) {
        ((Stage) btnConfirmar.getScene().getWindow()).close();
    }
}
