package Main;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Heladeria extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        FXMLLoader loader = new FXMLLoader(new java.io.File(
    "src/heladeria/controller/Login.fxml").toURI().toURL());
        Parent root = loader.load();
        Scene scene = new Scene(root);
        primaryStage.setTitle("Heladería Dulce Frío");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
